
import numpy as np
import pandas as pd
import time


X = pd.read_csv("data.csv", header=None).values.astype(float)
y = pd.read_csv("label.csv", header=None).values.ravel()
K = len(np.unique(y))     # K = number of true classes (10 for the digits dataset)
print(f"data shape: {X.shape}, K = {K}")


def euclidean_dist(A, B):
    # A: (n,d), B: (k,d) -> (n,k)
    return np.sqrt(((A[:, None, :] - B[None, :, :]) ** 2).sum(-1))

def cosine_dist(A, B):
    A_norm = A / (np.linalg.norm(A, axis=1, keepdims=True) + 1e-12)
    B_norm = B / (np.linalg.norm(B, axis=1, keepdims=True) + 1e-12)
    return 1.0 - A_norm @ B_norm.T

def jaccard_dist(A, B):
    n, k = A.shape[0], B.shape[0]
    D = np.zeros((n, k))
    for j in range(k):
        mn = np.minimum(A, B[j])      # (n,d)
        mx = np.maximum(A, B[j])
        num = mn.sum(axis=1)
        den = mx.sum(axis=1) + 1e-12
        D[:, j] = 1.0 - num / den
    return D

DISTS = {"euclidean": euclidean_dist, "cosine": cosine_dist, "jaccard": jaccard_dist}

# ---------- k-means ----------
def kmeans(X, K, dist_name, max_iter=100, stop_on_sse_increase=False,
           stop_on_no_change=True, tol=1e-6, seed=42):
    rng = np.random.default_rng(seed)
    # init: pick K random points as centroids
    idx = rng.choice(len(X), K, replace=False)
    centroids = X[idx].copy()

    dist_fn = DISTS[dist_name]
    prev_sse = np.inf
    sse_history = []
    iters_done = 0

    for it in range(max_iter):
        iters_done = it + 1
        D = dist_fn(X, centroids)            # (n, K)
        labels = D.argmin(axis=1)
        # SSE always uses squared Euclidean distance to its assigned centroid
        # (SSE is a Euclidean concept; this gives a fair cross-metric comparison)
        sse = ((X - centroids[labels]) ** 2).sum()
        sse_history.append(sse)

        # build new centroids
        new_centroids = np.zeros_like(centroids)
        for c in range(K):
            members = X[labels == c]
            if len(members) == 0:
                new_centroids[c] = X[rng.integers(0, len(X))]
            else:
                new_centroids[c] = members.mean(axis=0)

        shift = np.linalg.norm(new_centroids - centroids)

        # stopping criteria
        if stop_on_sse_increase and sse > prev_sse:
            break
        if stop_on_no_change and shift < tol:
            centroids = new_centroids
            break

        centroids = new_centroids
        prev_sse = sse

    return labels, centroids, sse_history, iters_done

# ---------- helpers ----------
def majority_vote_accuracy(labels, y_true, K):
    cluster_label = {}
    for c in range(K):
        mask = labels == c
        if mask.sum() == 0:
            cluster_label[c] = -1
            continue
        vals, counts = np.unique(y_true[mask], return_counts=True)
        cluster_label[c] = vals[counts.argmax()]
    pred = np.array([cluster_label[c] for c in labels])
    return (pred == y_true).mean()


print("\n=== Q1, Q2, Q3 ===")
for name in ["euclidean", "cosine", "jaccard"]:
    t0 = time.time()
    labels, _, sse_hist, iters = kmeans(
        X, K, name, max_iter=100,
        stop_on_no_change=True, stop_on_sse_increase=False, seed=42)
    elapsed = time.time() - t0
    acc = majority_vote_accuracy(labels, y, K)
    print(f"{name:10s}  final SSE = {sse_hist[-1]:.2f}   "
          f"accuracy = {acc:.4f}   iters = {iters}   time = {elapsed:.2f}s")


print("\n=== Q4: SSE per stop criterion ===")
print(f"{'metric':10s} {'no-change':>15s} {'sse-increase':>15s} {'max-100':>15s}")
for name in ["euclidean", "cosine", "jaccard"]:
    
    _, _, hA, _ = kmeans(X, K, name, max_iter=500,
                         stop_on_no_change=True, stop_on_sse_increase=False)
   
    _, _, hB, _ = kmeans(X, K, name, max_iter=500,
                         stop_on_no_change=False, stop_on_sse_increase=True)

    _, _, hC, _ = kmeans(X, K, name, max_iter=100,
                         stop_on_no_change=False, stop_on_sse_increase=False)
    print(f"{name:10s} {hA[-1]:15.2f} {hB[-1]:15.2f} {hC[-1]:15.2f}")
