
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from surprise import Dataset, Reader, SVD, KNNBasic
from surprise.model_selection import cross_validate

df = pd.read_csv("ratings_small.csv")
reader = Reader(rating_scale=(0.5, 5.0))
data = Dataset.load_from_df(df[["userId", "movieId", "rating"]], reader)


print("\n=== (c)(d) 5-fold CV: PMF vs User-CF vs Item-CF ===")
algos = {
    "PMF (SVD biased=False)": SVD(biased=False, random_state=42),
    "User-based CF":          KNNBasic(sim_options={"user_based": True},  verbose=False),
    "Item-based CF":          KNNBasic(sim_options={"user_based": False}, verbose=False),
}
results = {}
for name, algo in algos.items():
    cv = cross_validate(algo, data, measures=["RMSE", "MAE"], cv=5, verbose=False)
    rmse, mae = cv["test_rmse"].mean(), cv["test_mae"].mean()
    results[name] = (rmse, mae)
    print(f"{name:25s}  RMSE = {rmse:.4f}   MAE = {mae:.4f}")


print("\n=== (e) similarity metric impact ===")
sims = ["cosine", "msd", "pearson"]
sim_results = {"user": {}, "item": {}}
for s in sims:
    for ub_flag, key in [(True, "user"), (False, "item")]:
        algo = KNNBasic(sim_options={"name": s, "user_based": ub_flag}, verbose=False)
        cv = cross_validate(algo, data, measures=["RMSE", "MAE"], cv=5, verbose=False)
        sim_results[key][s] = (cv["test_rmse"].mean(), cv["test_mae"].mean())
        print(f"{key:5s}-CF  sim={s:8s}  RMSE = {sim_results[key][s][0]:.4f}  "
              f"MAE = {sim_results[key][s][1]:.4f}")

# plot
fig, ax = plt.subplots(1, 2, figsize=(11, 4))
x = np.arange(len(sims))
w = 0.35
ax[0].bar(x - w/2, [sim_results["user"][s][0] for s in sims], w, label="User-CF")
ax[0].bar(x + w/2, [sim_results["item"][s][0] for s in sims], w, label="Item-CF")
ax[0].set_xticks(x); ax[0].set_xticklabels(sims); ax[0].set_title("RMSE")
ax[0].legend()
ax[1].bar(x - w/2, [sim_results["user"][s][1] for s in sims], w, label="User-CF")
ax[1].bar(x + w/2, [sim_results["item"][s][1] for s in sims], w, label="Item-CF")
ax[1].set_xticks(x); ax[1].set_xticklabels(sims); ax[1].set_title("MAE")
ax[1].legend()
plt.tight_layout(); plt.savefig("similarity_impact.png", dpi=120)
print("saved -> similarity_impact.png")


print("\n=== (f)(g) impact of K ===")
ks = [5, 10, 15, 20, 25, 30, 40, 50, 70, 100]
k_results = {"user": [], "item": []}
for k in ks:
    for ub_flag, key in [(True, "user"), (False, "item")]:
        algo = KNNBasic(k=k, sim_options={"user_based": ub_flag}, verbose=False)
        cv = cross_validate(algo, data, measures=["RMSE"], cv=5, verbose=False)
        k_results[key].append(cv["test_rmse"].mean())
    print(f"K={k:3d}  user RMSE={k_results['user'][-1]:.4f}  "
          f"item RMSE={k_results['item'][-1]:.4f}")

best_user_k = ks[int(np.argmin(k_results["user"]))]
best_item_k = ks[int(np.argmin(k_results["item"]))]
print(f"\nbest K (User-CF) = {best_user_k}")
print(f"best K (Item-CF) = {best_item_k}")

plt.figure(figsize=(7, 4))
plt.plot(ks, k_results["user"], "o-", label="User-CF")
plt.plot(ks, k_results["item"], "s-", label="Item-CF")
plt.xlabel("K (neighbors)"); plt.ylabel("RMSE"); plt.legend(); plt.grid(alpha=0.3)
plt.title("RMSE vs number of neighbors")
plt.tight_layout(); plt.savefig("k_impact.png", dpi=120)
print("saved -> k_impact.png")
